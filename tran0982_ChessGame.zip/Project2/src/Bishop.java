//Written by Thuy-Yen Tran, tran0982

public class Bishop {
    private int row;

    private int col;

    private boolean isBlack;

    public Bishop(int row, int col, boolean isBlack){
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;

    }
    //move is legal as long as verifySourceAndDestination and verifyDiagonal are true; bishops move diagonally
    public boolean isMoveLegal(Board board, int endRow, int endCol){
        if (board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack)) {
            if(board.verifyDiagonal(this.row, this.col, endRow, endCol)){
                return true;
            }
        }
        return false;

    }

}
