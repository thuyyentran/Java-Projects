//Written by Thuy-Yen Tran, tran0982

public class Board {

    // Instance variables
    private Piece[][] board;

    private int row;

    private int col;


    public Board() {
        board = new Piece[8][8];
    }

    // Accessor Methods


    public Piece getPiece(int row, int col) {
        return this.board[row][col];
    }

    public void setPiece(int row, int col, Piece piece) {
        this.row = row;
        this.col = col;
        this.board[row][col] = piece;

    }

    // Game functionality methods


    //Checks is there is a piece at (startRow, startCol) AND if the move is legal
    //Moves the piece by setting the position from start to end and sets the start position to null
    public boolean movePiece(int startRow, int startCol, int endRow, int endCol) {
        if(board[startRow][startCol] != null && board[startRow][startCol].isMoveLegal(this,endRow,endCol)){
            board[endRow][endCol] = board[startRow][startCol];
            board[endRow][endCol].setPosition(endRow, endCol);
            board[startRow][startCol] = null;
            return true;

        }
        return false;
    }

    //Goes through each row and column on the board and checks for a king by keeping track of the count of kings on the board. If there are not 2 kings, a king of either color is missing, and the game is over.
    public boolean isGameOver() {
        int kingCount = 0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] != null && (board[i][j].getCharacter() == '\u265a'||board[i][j].getCharacter() == '\u2654')){
                    kingCount++;
                }
            }
        }
        return kingCount != 2;
    }

    //This constructs to Board of the game as a string by going through the columns and rows and adds either a space and '|'  or a chess piece and '|', depending if the cell of the array is null or not.
    public String toString() {
        String gameBoard = "Board:\n";
        gameBoard += '\u2001' +  "  0" + '\u2001' + "1" + '\u2001' + "2" + '\u2001' + "3" + '\u2001' + "4" + '\u2001' + "5" +'\u2001' + "6" + '\u2001' + "7" + '\u2001'; //the first line of the board.
        for (int i = 0; i < board.length; i++){
            gameBoard += "\n" + i + '\u2001' + "|";
            for(int j = 0; j < board[i].length; j++){
                if (board[i][j] == null) {
                    gameBoard += '\u2001';
                    gameBoard += "|";
                }
                else if (board[i][j] != null) {
                    gameBoard +=board[i][j].getCharacter();
                    gameBoard += "|";
                }

            }
       }
        return gameBoard;
    }

    //Checks through every row and column and checks if the square is null or not. If not, square is set to null.
    public void clear() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
               if (board[i][j] != null){
                   board[i][j] = null;
               }
            }
        }
    }

    // Movement helper functions



    // if conditions for verifySourceAndDestination are met, the booleanCount is incremented. this method is true only when the booleanCount is 5
    public boolean verifySourceAndDestination(int startRow, int startCol, int endRow, int endCol, boolean isBlack) {
        int booleanCount = 0;
        if(startRow >= 0 && startCol >= 0 && board.length > startRow && board.length > startCol ){
            booleanCount++;
        }
        // Checks if the end is within the bounds of the board
        if(endRow >= 0 && endCol >= 0 && board.length > endRow && board.length > endCol){
            booleanCount++;
        }
        //Checks if start contains a piece or not
        if(board[startRow][startCol] != null){
            booleanCount++;
        }
        //Checks if player's color and start piece color matches.
        if(board[startRow][startCol].getIsBlack() == isBlack){
            booleanCount++;
        }
        //Checks if end does not contain a piece OR end contains a piece of the opposite color
        if(board[endRow][endCol] == null || board[endRow][endCol] != null && board[startRow][startCol].getIsBlack() != board[endRow][endCol].getIsBlack()){
            booleanCount++;
        }

        return booleanCount == 5;
    }


    public boolean verifyAdjacent(int startRow, int startCol, int endRow, int endCol) {
        if(Math.abs(endRow-startRow) <= 1 && Math.abs(endCol-startCol) <= 1 ){ // checks whether the 'start' position and 'end' position are adjacent to each other
            return true;
        }
        return false;
    }


    public boolean verifyHorizontal(int startRow, int startCol, int endRow, int endCol) {
        if(startRow == endRow){ // checks if move is taking place on one row
            for(int i = Math.min(startCol, endCol) + 1; i < Math.max(startCol, endCol); i++) { //goes through the columns and makes sure the spaces between end and start are empty
                if (board[startRow][i] != null) {
                    return false;
                }
            } return true;

        }else {
            return false;
        }
    }


    public boolean verifyVertical(int startRow, int startCol, int endRow, int endCol) {
        if(startCol == endCol){ // checks if move is taking place on one column
            for(int i = Math.min(startRow, endRow) + 1; i < Math.max(startRow, endRow); i++) { ////goes through the columns and makes sure the spaces between end and start are empty
                if (board[i][startCol] != null) {
                    return false;
                }
            } return true;
        }else{
            return false;
        }
    }


    public boolean verifyDiagonal(int startRow, int startCol, int endRow, int endCol) {
        //finds the change in row and col
        int distRow = Math.abs(startRow - endRow);
        int distCol = Math.abs(startCol - endCol);

        if (distRow == distCol){
            if(startRow < endRow){ // if move is going top to bottom
                if(startCol < endCol) { // '' top left to bottom right
                    for (int i = startCol + 1; i < endCol; i++) { //this for and if statement and the ones below are to check if the spaces between are empty
                        if (board[startRow + i - startCol][i] != null) {
                            return false;
                        }
                    }
                }
                if(startCol > endCol) { // '' top right to bottom left
                    for (int i = startCol - 1; i > endCol; i--) {
                        if (board[startRow - i + startCol][i] != null) {
                            return false;
                        }
                    }
                }
            } else if (endRow < startRow) { //'' bottom to top
                if(startCol < endCol) { // '' bottom left to top right
                    for (int i = startCol + 1; i < endCol; i++) {
                        if (board[startRow - i + startCol][i] != null) {
                            return false;
                        }
                    }
                }
                if(startCol > endCol) { //'' bottom right to top left
                    for (int i = startCol - 1; i > endCol; i--){
                        if (board[startRow + i - startCol][i] != null) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }else{
            return false;
        }
    }
}
