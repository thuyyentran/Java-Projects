//Written by Thuy-Yen Tran, tran0982

public class Knight {
    private int row;

    private int col;

    private boolean isBlack;

    public Knight(int row, int col, boolean isBlack){
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;

    }
    //move is legal as long as verifySourceAndDestination and checks the difference between the spaces between the columns and rows
    public boolean isMoveLegal(Board board, int endRow, int endCol){
        if (board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack)) {
            int subRow = Math.abs(this.row - endRow);
            int subCol = Math.abs(this.col - endCol);

            if((subRow == 1 && subCol == 2) || subCol == 1 && subRow == 2){ //difference in rows must equal 1, while the difference in columns equals 2; or vice versa
                return true;
            }

        }
        return false;
    }
}
