//Written by Thuy-Yen Tran, tran0982

import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        Board gameBoard = new Board();
        Fen.load("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", gameBoard);
        Scanner myScanner = new Scanner(System.in);

        boolean isBlack = true;
        while (!gameBoard.isGameOver()) {
            System.out.println(gameBoard);
            isBlack = !isBlack; //this switches if isBlack is true or false with every run through the while loop

            String player = isBlack ? "Black's Turn!" : "White's Turn!"; // '?' allows for the first string "Black's Turn!" to be for when isBlack is true; when false, "White's Turn!" is printed
            System.out.print(player + " (format:[start row] [start col] [end row] [end col]) >>> ");

            String[] inputMove = myScanner.nextLine().split(" ");
            int startRow = Integer.parseInt(inputMove[0]);
            int startCol = Integer.parseInt(inputMove[1]);
            int endRow = Integer.parseInt(inputMove[2]);
            int endCol = Integer.parseInt(inputMove[3]);

            // while conditions are not met, player will be asked to input a new move until it is a legal one
            while (!(gameBoard.getPiece(startRow,startCol) != null && gameBoard.getPiece(startRow, startCol).getIsBlack() == isBlack && gameBoard.movePiece(startRow, startCol, endRow, endCol))){
                System.out.println("Illegal Move. Try again");
                player = isBlack ? "Black" : "White";
                System.out.print(player + " >>> ");
                inputMove = myScanner.nextLine().split(" ");
                startRow = Integer.parseInt(inputMove[0]);
                startCol = Integer.parseInt(inputMove[1]);
                endRow = Integer.parseInt(inputMove[2]);
                endCol = Integer.parseInt(inputMove[3]);
            }
            gameBoard.getPiece(endRow,endCol).pawnPromotion(isBlack); //meant to check for pawn promotion
        }
        System.out.println(gameBoard);
        System.out.println("Game Over!");


    }
}

