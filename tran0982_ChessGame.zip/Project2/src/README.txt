Thuy-Yen Tran
tran0982

My Program can be compiled and run in IntelliJ.  To play the game, run the Game.java class in IntelliJ.
Assumptions:
    N/A
Additional Features:
    pawnPromotion, which is at the bottom of the Piece Class.
Bugs/defects:
    Please be careful when typing in your move, as a simple typo could result in IntelliJ exiting you from the code.


I certify that the information contained in this README file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
- Thuy-Yen Tran