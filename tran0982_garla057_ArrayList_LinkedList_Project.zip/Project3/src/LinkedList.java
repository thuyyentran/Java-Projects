// Written by: Ivy Garland (garla057) & Thuy-Yen Tran (tran0982)

public class LinkedList <T extends Comparable<T>> implements List<T> {
    private Node<T> head; // first node, NOT headed
    private boolean isSorted;

    public LinkedList() {
        head = null;
        isSorted = true;

    }

    @Override
    public boolean add(T element) {
        Node<T> ptr = head;
        if (element == null) { // special case
            return false;
        }

        Node<T> newNode = new Node<>(element); // adding newNode to end of list
        if (head == null) { // special case
            head = newNode;
        }
        else {
            while (ptr.getNext() != null) {
                    ptr = ptr.getNext();
            }
            ptr.setNext(newNode);
            if (newNode.getData().compareTo(ptr.getData()) < 0) { // isSorted check
                isSorted = false;
            }
        }

        return true;
    }

    @Override
    public boolean add(int index, T element) {
        Node <T> ptr = head;

        if (element == null || index < 0 || index >= size()) { // special case
            return false;
        }

        if (index == 0) { // special case
            head = new Node<> (element,head); // isSorted check
            if (element.compareTo(ptr.getData()) > 0) { // is
                isSorted = false;
            }
            return true;
        }
        else { // inserting newNode at specified index
            for (int i = 0; i < index - 1; i++) {
                ptr = ptr.getNext();
            }
            Node<T> trailer = ptr.getNext();
            ptr.setNext(new Node<>(element, trailer));

            if (element.compareTo(ptr.getData()) < 0 || element.compareTo(trailer.getData()) > 0) { // isSorted check
                isSorted = false;
            }
        }
//        isSorted = isStillSorted();

        return true;
    }

    @Override
    public void clear() {
        head = null;
        isSorted = true; // nothing in list, list is sorted
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= size()) { // special case
            return null;
        }

        Node<T> ptr = head;
        int i = 0;
        while (i++ < index) { // finding value at index
            ptr = ptr.getNext();
        }
        return ptr.getData();
    }

    @Override
    public int indexOf(T element) {
        Node<T> ptr = head;
        int index = 0;
        while (ptr != null) {
            if (isSorted && element.compareTo(ptr.getData()) < 0) {
                return -1;
            }
            if (element.compareTo(ptr.getData()) == 0) {
                return index;
            }
            index++;
            ptr = ptr.getNext();
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        if (size() == 0) {
            return true;
        }
        return false;
    }

    @Override
    public int size() { // instead of using class attribute
        Node<T> ptr;
        int size = 0;
        for (ptr = head; ptr!=null; ptr = ptr.getNext()) {
            size++;
        }
        return size;
    }

    @Override
    public void sort() {
        // insertion sort: stable and more efficient than bubble in this case
        if (isSorted) { } // special case, do nothing
        else {
            Node<T> ptr = head;
            Node<T> trailer;
            T temp;
            if (head == null) { } // special case, do nothing, empty list
            else {
                while (ptr != null) {
                    trailer = ptr.getNext();
                    while (trailer != null) { // value comparison check & swap if needed
                        if (ptr.getData().compareTo(trailer.getData()) > 0) {
                            temp = ptr.getData();
                            ptr.setData(trailer.getData());
                            trailer.setData(temp);
                        }
                        trailer = trailer.getNext();
                    }
                    ptr = ptr.getNext();
                }
            }
            isSorted = true;
        }
    }

    @Override
//        TODO Auto-generated method stub
    public T remove (int index) { // keep!! -- check isSorted!!
        Node <T> ptr = head;
        Node <T> trailer = head;

        if (index < 0 || index > size()) { // special case
            return null;
        }

        while (head != null) {
            if (index == 0) {
                head = ptr.getNext();
                isSorted = isStillSorted();
                return ptr.getData();
            }

            for (int i = 0; i < index; i++) {
                if (ptr.getNext() == null) {
                    return null;
                }
                if (ptr != head) {
                    trailer = trailer.getNext();
                }
                ptr = ptr.getNext(); //ptr should equal the node @ index
            }
            Node<T> removed = ptr;
            trailer.setNext(ptr.getNext());

            isSorted = isStillSorted();

            return removed.getData();
        }

        return null;
    }

    @Override
    public void equalTo(T element) {
        Node<T> start = null;
        Node<T> ptr = head;
        while(ptr != null) {
            if(ptr.getData().compareTo(element) != 0){
                if(ptr == head){ // special case
                    head = ptr.getNext();
                    ptr = head;
                }
                else{
                    start.setNext(ptr.getNext());
                    ptr = ptr.getNext();
                }
            }
            else{
                start = ptr;
                ptr = ptr.getNext();
            }
        }
        isSorted = true;
    }

    @Override
    public void reverse() {
        // based on "Reverse.java" on Canvas page
        if (head == null || head.getNext() == null) { // special case
            return;  // only one node, so nothing to reverse
        }
        Node<T> ptr = head.getNext();  // ptr node moves to front
        Node<T> trailer = head;
        while (ptr != null) {
            trailer.setNext(ptr.getNext());  // link around ptr node
            ptr.setNext(head);  // link ptr to front of list
            head = ptr; // link head to ptr
            ptr = trailer.getNext();  // advance to next node to move
        }

        isSorted = isStillSorted();
    }

    @Override
    public void merge(List<T> otherList) {
        if (!this.isEmpty() && !otherList.isEmpty()) { // can't merge empty lists
            LinkedList<T> other = (LinkedList<T>) otherList; // given
            sort();
            other.sort();
            isSorted = true;

            Node<T> ptr1 = this.head.getNext();
            Node<T> trailer1 = this.head;
            Node<T> ptr2 = other.head.getNext();
            Node<T> trailer2 = other.head;

            while (ptr1 != null && ptr2 != null) { // ptrs exist for both lists (i.e. one list hasn't ended)
                if (trailer2.getData().compareTo(trailer1.getData()) >= 0 && (trailer2.getData().compareTo(ptr1.getData()) <= 0)) { // found a spot in original list
                    ptr2 = trailer2.getNext();
                    trailer1.setNext(trailer2);
                    trailer2.setNext(ptr1);
                    trailer1 = trailer2;
                    trailer2 = ptr2;
                    ptr2 = trailer2.getNext();
                }
                else { // transversing through
                    ptr1 = ptr1.getNext();
                    trailer1 = trailer1.getNext();
                }
            }

            if (ptr2 == null) { // otherList has 1 element left
                while (ptr2 == null) {
                    if (trailer2.getData().compareTo(trailer1.getData()) > 0 && (trailer2.getData().compareTo(ptr1.getData()) > 0)) { // transverse through list for correct spot
                        ptr1 = ptr1.getNext();
                        trailer1 = trailer1.getNext();
                    }
                    else if (trailer2.getData().compareTo(trailer1.getData()) >= 0 && (trailer2.getData().compareTo(ptr1.getData()) <= 0)) { // found correct spot
                        trailer1.setNext(trailer2);
                        trailer2.setNext(ptr1);
                    }
                }
            }

            if (ptr1 == null) { // if the first list (i.e. combined list) has run out first
                trailer1.setNext(trailer2);
            }
        }
    }

    /**
     * Pair swap takes the elements of the list in groups of two and swaps them. This swap must be
     * down IN PLACE. Do not use any extra data structures to solve this problem. If the number of
     * values is odd, then the last value in the list should stay in place.
     * For example, take the list [1,2,3,4,5]. Pair swap with return the list [2,1,4,3,5].
     *
     */
    @Override
    public void pairSwap() { // works!!
        Node<T> temp = head;
        while (temp != null && temp.getNext() != null) {
            T val = temp.getData();
            temp.setData(temp.getNext().getData());
            temp.getNext().setData(val);
            temp = temp.getNext().getNext();

        }
        isSorted = isStillSorted();
    }
    public boolean isStillSorted() {
        Node<T> trailer = head;
        if (trailer == null) {
            return true;
        }
        while (trailer.getNext() != null) {
            if (trailer.getData().compareTo(trailer.getNext().getData()) > 0) {
                return false;
            }
            trailer = trailer.getNext();
        }
        return true;
    }

    @Override
    public boolean isSorted() {
        return isSorted;
    }

    public String toString() {
        String list = "";
        Node<T> ptr = head;
        while(ptr != null){
            list += ptr.getData();
            list += "\n";
            ptr = ptr.getNext();
        }
        return list;
    }
}