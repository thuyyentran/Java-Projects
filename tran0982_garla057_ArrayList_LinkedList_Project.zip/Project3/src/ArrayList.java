import java.util.Random;
//Written by: Ivy Garland (garla057) & Thuy-Yen Tran (tran0982)

public class ArrayList<T extends Comparable<T>> implements List<T> {

    private T[] a;

    private int index;

    private int howMany = 0;

    private boolean isSorted = true;

    public ArrayList() {
        a = (T[]) new Comparable[2];

    }
    @Override
    public boolean add(T element) { // adds element to the end of the list, increments howMany(size), and updates isSorted
        T[] newArray;
        if( element == null ){
            return false;
        }
        else if(howMany >= a.length){ //resizing a to allow for the addition of elements to the list
            newArray = (T[]) new Comparable[a.length * 2];
            System.arraycopy(a, 0, newArray, 0, howMany);
            a = newArray;
        }
        a[howMany] = element;
        howMany++;
        isSorted = checkSorted();
        return true;
    }

    @Override
    public boolean add(int index, T element) { //adds element at specific index, increments howMany(size), and updates isSorted
        if( element == null || index < 0 || index >= howMany ){ //checks if index is out of bounds
            return false;
        }
        else if(howMany >= a.length){
            T[] newArray;
            newArray = (T[]) new Comparable[a.length * 2];
            System.arraycopy(a, 0, newArray, 0, a.length);
            a = newArray;
        }
        for(int i = howMany-1; i >= index; i--){ //shifts elements to the right
            a[i + 1] = a[i];
        }
        a[index] = element;
        howMany++;
        isSorted = checkSorted();
        return true;
    }

    @Override
    public void clear() { //removes all elements form list
        for(int i = 0; i < a.length; i++){
            howMany = 0;
            isSorted = true;

        }

    }

    @Override
    public T get(int index) { //return element at given index
        if (index < 0 || index >= howMany){ //checks if index is out of bounds
            return null;
        }
        else{
            return a[index];
        }
    }

    @Override
    public int indexOf(T element) {

        if(element == null) {
            return -1;
        }
        if(isSorted){ //using ordering of list to increase efficiency of the search
            for (int i = 0; i < howMany; i++) {
                if (a[i].compareTo(element) > 0) {
                    return -1;
                }
                else if (a[i].compareTo(element) == 0) {
                    return i;
                }
            }
        }
        else {
            for (int i = 0; i < howMany; i++) { // for when isSorted is false
                if (a[i].compareTo(element) == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    @Override
    public boolean isEmpty() { //return boolean for whether list is empty or not
        if(howMany == 0){
            return true;
        }
        return false;
    }

    @Override
    public int size() {
        return howMany;
    }

    @Override
    public void sort() { //sorts the list using insertion method
       if(!isSorted) { //increase efficiency because it will only sort when isSorted is false
            T temp;
            int i, j;
            for (i = 1; i < howMany; i++) {
                temp = a[i];
                for (j = i - 1; j >= 0 && temp.compareTo(a[j]) <= 0; j--) {
                    a[j + 1] = a[j];
                }
                a[j + 1] = temp;
            }
            isSorted = true;
        }
    }

    @Override
    public T remove(int index) { //removes element, decreases howMany(size), updates isSorted
        if( index < 0 || index >= howMany ) {
            return null;
        }
        T element = a[index]; //the element being removed

        for(int i = index + 1; i <= howMany-1; i++){ //shifting elements
            a[i - 1] = a[i];
        }

        howMany--;
        isSorted = checkSorted();
        return element;
    }

    @Override
    public void equalTo(T element) {

        int ele = 0; //keeps track of the number of elements equal to 'element'
        if (element == null){
            return;
        }
        for(int i = 0; i < howMany; i++){
            if (a[i].compareTo(element) == 0){ //if element is the same as the element in array, increment ele
                ele++;
            }
            else if(isSorted && a[i].compareTo(element) > 0) {
                break;
            }
        }
        for(int i = 0; i < ele; i++){ //sets all indexes less than ele in array to be the element
            a[i] = element;
        }
        howMany = ele;
        isSorted = true;
    }

    @Override
    public void reverse() {
        if(howMany > 1) { // makes sure list is more than 1
            for (int i = 0; i < howMany/2 ; i++) { //goes through first half of list and swaps first element with last and so on
                T temp = a[i];
                a[i] = a[howMany - i - 1];
                a[howMany - i - 1] = temp;
            }
        }
        isSorted = checkSorted();
    }

    @Override
    public void merge(List<T> otherList) {
        ArrayList<T> other = (ArrayList<T>) otherList;
        sort();
        other.sort();
        int amount = size() + other.size(); //the size of both arrays combined
        T[] newArray;
        newArray = (T[]) new Comparable[amount];
        int ele1 = 0; //index for a
        int ele2 = 0; //index for other
        int index = 0; // index for newArray

        while(ele1 < howMany && ele2 < other.howMany){ //comparing a to other
            if(a[ele1].compareTo(other.a[ele2]) < 0){
                newArray[index++] = a[ele1++]; //adding to new array
            }
            else{
                newArray[index++] = other.a[ele2++];
            }
        }

        while(ele1 < howMany){  //adding all remaining elements form a
            newArray[index++] = a[ele1++];
        }

        while(ele2 < other.howMany) { //adding all remaining elements from other
            newArray[index++] = other.a[ele2++];
        }

        howMany += other.howMany;
        a = newArray;
        isSorted = true;
    }

    @Override
    public void pairSwap() {
        if(howMany > 2) { // makes sure list has more than two elements
            for (int i = 0; i < howMany - 1; i+=2) { //to swap in pairs of two
                T temp = a[i];
                a[i] = a[i+1];
                a[i+1] = temp;
            }

        }

    }

    public boolean checkSorted() { //helper method
        for(int i = 0; i < howMany-1; i++){ //checking if array is sorted
            if(a[i].compareTo(a[i+1]) > 0){
                return false;
            }
        }
        return true;
    }

    @Override
    public boolean isSorted() {
        return isSorted;
    }

    @Override
    public String toString(){
    String out = "";
    for( int i = 0; i < a.length; i++){
        out += a[i] + ",";
        }
        return out;
    }

}
